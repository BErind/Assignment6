package pet;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class GUI {
	public static String cartStr = "";
	public static int cartPriceInt = 0;
	public static String nowUser = "";
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException{
		final String USER = "root";
		final String PASS = "123456";
		Connection conn = null;
		final String DB_URL = "jdbc:mysql://127.0.0.1:3306/my_schema";
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(DB_URL,USER,PASS);
		final Statement stmt =  conn.createStatement();

		
		//������
		JFrame jf = new JFrame("���ｻ��ϵͳ");
		jf.setLayout(null);
		jf.setBounds(0,0,400,300);
		Container container = jf.getContentPane();
		
		JLabel userLabel = new JLabel("�˺ţ�");
		JLabel passwordLabel = new JLabel("���룺");
		JLabel newUserLabel = new JLabel("���˺ţ�");
		JLabel newPasswordLabel = new JLabel("���룺");
		JLabel warn = new JLabel("�˺Ż��������������");
		JLabel nowCart = new JLabel("");
		
		JLabel pet1 = new JLabel("test1");
		JLabel pet2 = new JLabel("test2");
		JLabel pet3 = new JLabel("test3");
		JLabel pet4 = new JLabel("test4");
		
		JCheckBox buy1 = new JCheckBox();
		JCheckBox buy2 = new JCheckBox();
		JCheckBox buy3 = new JCheckBox();
		JCheckBox buy4 = new JCheckBox();
		
		String sql1 = "select * from 2014302580059_pet";
		ResultSet petData = stmt.executeQuery(sql1);
		if(petData.next()){
			pet1.setText("name:"+petData.getString(2)+" summary:"+petData.getString(3)+" price:"+petData.getInt(4));
		}
		if(petData.next()){
			pet2.setText("name:"+petData.getString(2)+" summary:"+petData.getString(3)+" price:"+petData.getInt(4));
		}
		if(petData.next()){
			pet3.setText("name:"+petData.getString(2)+" summary:"+petData.getString(3)+" price:"+petData.getInt(4));
		}
		if(petData.next()){
			pet4.setText("name:"+petData.getString(2)+" summary:"+petData.getString(3)+" price:"+petData.getInt(4));
		}
		
		JButton land = new JButton("��½");
		JButton register = new JButton("ע��");
		JButton newRegister = new JButton("ȷ��ע��");
		JButton buy = new JButton("���빺�ﳵ");
		JButton cart = new JButton("�鿴���ﳵ");
		JButton toBuy = new JButton("ȷ�Ϲ���");
		
		JTextField user = new JTextField();
		JPasswordField password = new JPasswordField();
		JTextField newUser = new JTextField();
		JPasswordField newPassword = new JPasswordField();
		
		register.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				container.removeAll();
				container.repaint();
				container.add(newUserLabel);
				container.add(newPasswordLabel);
				container.add(newUser);
				container.add(newPassword);
				container.add(newRegister);
			}
		});
		newRegister.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				int temp = 0;
				container.removeAll();
				container.repaint();
				container.add(userLabel);
				container.add(passwordLabel);
				container.add(user);
				container.add(password);
				container.add(register);
				container.add(land);
				String sql = "select * from 2014302580059_user";
				ResultSet userId = null;
				try {
					userId = stmt.executeQuery(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					try {
						while(userId.next()){
							temp = userId.getInt(1)+1;
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				System.out.println(temp+newUser.getText()+newPassword.getText());
				try {
					stmt.executeUpdate("insert into 2014302580059_user values('"+temp+"','"+newUser.getText()+"','"+newPassword.getText()+"',"+"'3000'"+",'','0'"+");");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		land.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String sql = "select * from 2014302580059_user";
				ResultSet userData = null;
				boolean right = false;
				try {
					userData = stmt.executeQuery(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					while(userData.next()){
						if(user.getText().equals(userData.getString(2))&&password.getText().equals(userData.getString(3))){
							right = true;
						}
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(!right){
					container.add(warn);
					container.repaint();
				}
				else{
					nowUser = user.getText();
					container.removeAll();
					container.repaint();
					container.add(pet1);
					container.add(pet2);
					container.add(pet3);
					container.add(pet4);
					container.add(buy1);
					container.add(buy2);
					container.add(buy3);
					container.add(buy4);
					container.add(buy);
					container.add(cart);
				}
			}
		});
		buy1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				cartStr += "dog*1;";
				cartPriceInt += 1000;
			}
		});
		buy2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				cartStr += "cat*1;";
				cartPriceInt += 1000;
			}
		});
		buy3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				cartStr += "parrot*1;";
				cartPriceInt += 500;
			}
		});
		buy4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				cartStr += "rabbit*1;";
				cartPriceInt += 200;
			}
		});
		buy.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String sql = "update 2014302580059_user set cart='"+cartStr+"' where name='"+nowUser+"';";
				try {
					stmt.executeUpdate(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				sql = "update 2014302580059_user set cartPrice='"+cartPriceInt+"' where name='"+nowUser+"';";
				try {
					stmt.executeUpdate(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		cart.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String sql = "select cart,cartPrice from 2014302580059_user where name='"+nowUser+"';";
				ResultSet userCart = null;
				try {
					userCart = stmt.executeQuery(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                            try {
								while(userCart.next()){
										nowCart.setText(userCart.getString(1)+" �ܼƣ�"+userCart.getInt(2));
								}
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}




				container.removeAll();
				container.add(nowCart);
				container.add(toBuy);
				container.repaint();
			}
		});
		toBuy.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				int gold = 0;
				String sql = "select purchase,cartPrice from 2014302580059_user where name='"+nowUser+"';";
				ResultSet purchase = null;
				try {
					purchase = stmt.executeQuery(sql);
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					while(purchase.next()){
						gold = purchase.getInt(1)-purchase.getInt(2);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				sql = "update 2014302580059_user set purchase='"+gold+"',cart='',cartPrice='0' where name ='"+nowUser+"';";
				try {
					stmt.executeUpdate(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		land.setBounds(100,180,80,30);
		register.setBounds(220,180,80,30);
		userLabel.setBounds(80,40,40,30);
		passwordLabel.setBounds(80,100,40,30);
		newUserLabel.setBounds(60,40,60,30);
		newPasswordLabel.setBounds(80,100,40,30);
		user.setBounds(130,40,160,30);
		password.setBounds(130,100,160,30);
		newUser.setBounds(130,40,160,30);
		newPassword.setBounds(130,100,160,30);
		newRegister.setBounds(120,180,160,30);
		warn.setBounds(130,140,200,30);
		
		buy.setBounds(60,200,100,30);
		cart.setBounds(200,200,100,30);
		
		pet1.setBounds(40,10,300,30);
		pet2.setBounds(40,50,300,30);
		pet3.setBounds(40,90,300,30);
		pet4.setBounds(40,130,300,30);
		
		buy1.setBounds(340,10,20,20);
		buy2.setBounds(340,50,20,20);
		buy3.setBounds(340,90,20,20);
		buy4.setBounds(340,130,20,20);
		
		nowCart.setBounds(40,50,300,30);
		toBuy.setBounds(100,120,120,30);
		
		container.add(land);
		container.add(register);
		container.add(userLabel);
		container.add(passwordLabel);
		container.add(user);
		container.add(password);

		
		jf.setVisible(true);
		
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
}
